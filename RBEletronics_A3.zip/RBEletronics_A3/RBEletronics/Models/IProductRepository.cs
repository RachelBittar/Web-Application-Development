﻿using System.Linq;

namespace RBEletronics.Models {

    public interface IProductRepository {

        IQueryable<Product> Products { get; }

        void SaveProduct(Product product);
        void AddProductForm(Product p);

        Product DeleteProduct(int productID);
    }
}
