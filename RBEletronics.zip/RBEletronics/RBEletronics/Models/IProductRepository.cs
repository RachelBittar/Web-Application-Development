﻿using System.Linq;

namespace RBEletronics.Models {

    public interface IProductRepository {

        IQueryable<Product> Products { get; }
     
    }
}
