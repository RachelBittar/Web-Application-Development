﻿using System.Linq;
using System.Collections.Generic;

namespace RBEletronics.Models {

    public interface IProductRepository {

	   IQueryable<Product> getProducts();
	  //void AddProductForm(Product item);
      //  IQueryable<Product> Products { get; }


      //  IEnumerable<Product> Products { get; }
        void AddProductForm(Product item);
    }
}
