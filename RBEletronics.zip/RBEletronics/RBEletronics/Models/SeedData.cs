﻿using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace RBEletronics.Models {

    public static class SeedData {

        public static void EnsurePopulated(IApplicationBuilder app) {
            ApplicationDbContext context = app.ApplicationServices
                .GetRequiredService<ApplicationDbContext>();
            context.Database.Migrate();
            if (!context.Products.Any()) {
                context.Products.AddRange(
                     new Product
                     {
                      //   ProductID = 1,
                         Name = "Acer Aspire ",
                         Description = "A315-21-656 15.6” Laptop with AMD A6 9220 Processor, 1TB HDD, 8GB RAM, AMD Radeon R4 Graphics, & Windows 10 - Bilingual - Black",
                         Category = "Computer",
                         Price = 429

                     },
                    new Product
                    {
                     //   ProductID = 2,
                        Name = "ASUS VivoBook",
                        Description = "X541UA-RS31-CB 15.6” Laptop with Intel® i3-6006U, 1TB HDD, 8GB RAM & Windows 10 - Black & Gold",
                        Category = "Computer",
                        Price = 329
                    },
                    new Product
                    {
                     //   ProductID = 3,
                        Name = "Acer Aspire",
                        Description = "ES1-531-C6FQ 15.6” Laptop with Intel® N3050, 500GB HDD, 4GB RAM & Windows 10 ",
                        Category = "Computer",
                        Price = 396
                    },
                    new Product
                    {
                      //  ProductID = 4,
                        Name = "Canon MAXIFY MB2120 Wireless",
                        Description = "All-in-One Inkjet Printer with 2.5” LCD, Fax, ADF, 2-Sided Printing & 250 Page Cassette",
                        Category = "Laser Printer",
                        Price = 109
                    },
                    new Product
                    {
                      //  ProductID = 5,
                        Name = "Canon PIXMA G3200 ",
                        Description = "Multifunction MegaTank Inkjet Printer",
                        Category = "Laser Printer",
                        Price = 299
                    },
                    new Product
                    {
                      //  ProductID = 6,
                        Name = "Samsung Galaxy Tab E 9.6” ",
                        Description = "Tablet with 1.2GHz Quad-Core Processor & 16GB of Storage - White - SM-T560NZWUXAC",
                        Category = "Mobile",
                        Price = 169
                    },
                    new Product
                    {
                     //   ProductID = 7,
                        Name = "Samsung Galaxy Tab A 7”",
                        Description = "Tablet with 1.3GHz Quad-Core Processor, 8GB & Android 5.1 - White",
                        Category = "Mobile",
                        Price = 291
                    },
                    new Product
                    {
                      //  ProductID = 8,
                        Name = "Samsung Galaxy",
                        Description = "Explosion!",
                        Category = "Mobile",
                        Price = 75
                    },
                    new Product
                    {
                       // ProductID = 9,
                        Name = "Iphone",
                        Description = "IPhone x",
                        Category = "Mobile",
                        Price = 1200
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
