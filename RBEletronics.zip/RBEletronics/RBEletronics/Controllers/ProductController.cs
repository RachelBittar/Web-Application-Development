﻿using Microsoft.AspNetCore.Mvc;
using RBEletronics.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

using RBEletronics.Models.ViewModels;

namespace RBEletronics.Controllers {

    public class ProductController : Controller
    {
        private IProductRepository repository;
        public int PageSize = 4;

        public ProductController(IProductRepository repo)
        {
            repository = repo;
        }


        public ViewResult Index(Product product)
        {
            return View(new ProductsListViewModel
            {
                Products = repository.getProducts()

            });
        }

        [HttpGet]
        public IActionResult AddProductForm()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddProductForm(Product newProduct)
        {
            if (ModelState.IsValid)
            {
                repository.AddProductForm(newProduct);
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

       
        public ViewResult List(string category, int productPage = 1)
        => View(new ProductsListViewModel
        {
            Products = repository.getProducts()
            .Where(p => category == null || p.Category == category)
            .OrderBy(p => p.ProductID)
            .Skip((productPage - 1) * PageSize)
            .Take(PageSize),
            PagingInfo = new PagingInfo
            {
                CurrentPage = productPage,
                ItemsPerPage = PageSize,
                TotalItems = category == null ?
                repository.getProducts().Count() :
                repository.getProducts().Where(e =>
                e.Category == category).Count()
            },
            CurrentCategory = category
        });



    }
}
